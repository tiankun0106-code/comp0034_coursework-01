# Tourism Recovery Analytics Dashboard

COMP0034 Coursework 1 - Interactive web application for analyzing international visitor arrivals by sea.

## Project Overview

This Dash web application provides an interactive analytics dashboard for exploring international visitor arrival data, with features including:

- **Dashboard**: KPI cards, yearly trend charts, top markets, regional market share, and seasonal heatmaps
- **Data Explorer**: Multi-market selection, year filtering, monthly time series comparison, sortable/filterable data table, and JSON export
- **COVID Recovery Analysis**: Compare pre-COVID baseline with post-COVID data, recovery rate visualization

## Project Structure

```
comp0034-cw1/
├── src/
│   └── tourism_dashboard/
│       ├── __init__.py
│       ├── app.py              # Main Dash application (entry point)
│       ├── layout.py           # Dashboard layout and components
│       ├── callbacks.py        # Interactive callback functions
│       └── data_access.py      # Data access layer (JSON-structured)
├── tests/
│   ├── __init__.py
│   ├── conftest.py             # Pytest fixtures
│   ├── test_data_access.py     # Unit/integration tests for data layer
│   └── test_browser.py         # Selenium browser tests
├── data/
│   └── international_visitor_arrivals.db
├── pyproject.toml
├── submission.yml
└── README.md
```

## Installation

### Prerequisites
- Python 3.12 or higher
- pip package manager
- Google Chrome (for browser tests)

### Setup

1. **Create and activate virtual environment**:
   ```bash
   python -m venv .venv

   # Windows
   .venv\Scripts\activate

   # macOS/Linux
   source .venv/bin/activate
   ```

2. **Install the package**:
   ```bash
   pip install -e .
   ```

3. **Install dev dependencies** (for testing):
   ```bash
   pip install -e ".[dev]"
   ```

## Running the Application

```bash
python src/tourism_dashboard/app.py
```

Then open http://127.0.0.1:8050 in your browser.

## Running Tests

### Run all tests:
```bash
python -m pytest
```

### Run data access tests only:
```bash
python -m pytest tests/test_data_access.py -v
```

### Run browser tests only:
```bash
python -m pytest tests/test_browser.py -v
```

### Run with coverage:
```bash
python -m pytest --cov=src --cov-report=html --cov-report=term
```

## Data Source

International Visitor Arrivals By Inbound Tourism Markets (Sea), Monthly.

Licensed under the [Open Government Licence v3](https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/).
